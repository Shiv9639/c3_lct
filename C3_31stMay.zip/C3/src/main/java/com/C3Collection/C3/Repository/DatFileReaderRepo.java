package com.C3Collection.C3.Repository;

import com.C3Collection.C3.Model.C3Master;
import com.C3Collection.C3.Model.DatFileReader;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DatFileReaderRepo extends MongoRepository<DatFileReader, String> {
}
