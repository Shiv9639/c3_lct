package com.C3Collection.C3.Repository;

import com.C3Collection.C3.Model.C3Master;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface C3MasterRepo extends MongoRepository<C3Master, String> {

}