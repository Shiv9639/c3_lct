package com.C3Collection.C3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C3Application {

	public static void main(String[] args) {
		SpringApplication.run(C3Application.class, args);
	}

}
