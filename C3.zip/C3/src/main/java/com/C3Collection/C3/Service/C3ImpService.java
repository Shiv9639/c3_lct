package com.C3Collection.C3.Service;

import com.C3Collection.C3.Model.C3Master;
import com.C3Collection.C3.Model.R9333LpvPoInterface;
import com.C3Collection.C3.Repository.C3MasterRepo;
import com.C3Collection.C3.Repository.R9333LpvPoInterfaceRepo;
import com.opencsv.CSVWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

@Service
public class C3ImpService {


    @Autowired
    private C3MasterRepo repository;
    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private R9333LpvPoInterfaceRepo r9333LpvPoInterfaceRepo;

    public void C3DataFiltering() throws Exception {

        List<C3Master> l = repository.findAll();
        //System.out.println("from C3 "+l);

        //int flag_check_po=0;
        List<String> po = new ArrayList<>();
        //	File file = new File("/home/shivang/Documents/C3Collection.csv");
        //FileWriter outputfile = new FileWriter(file);
        //List<String[]> data = new ArrayList<String[]>();
        //CSVWriter writer = new CSVWriter(outputfile);


        String SUB_State_Time = "";

        String DO_format = "";
        //data.add(new String[] {"Order No", "Order Type", "Process Type", "Customer", "Supplier","Operation Name" ,"UDF C3 Sub State","Sub State Time","Door Number"});
        //writer.writeAll(data);
        List<String[]> actual_data = new ArrayList<String[]>();
        int i = 0;
        for (C3Master c3 : l) {
            //flag_check_po=0;
            if (c3 != null) {

                String po_no = c3.getPurchaseOrderNumber();
                String[] split_po = po_no.split(",");

                if ((split_po.length) > 1) {
                    if (!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !c3.getSite_ExternalReference().trim().equals("")) {
                        if ((c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) ||
                                (c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door"))

                                || (c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused"))) {
                            if (c3.getSite_ExternalReference().length() == 1) {
                                String append_O = "0" + c3.getSite_ExternalReference();
                                DO_format = "DO" + append_O;
                            } else if (c3.getSite_ExternalReference().length() == 2) {
                                DO_format = "DO" + c3.getSite_ExternalReference();
                            }


                            String Current_WorkFlow = c3.getCurrent_WorkflowStateName_ID();
                            String d_format = DO_format;
                            for (String s : split_po) {
                                //flag_check_po=0;
                                //c3DataToMongo=new C3DataToMongo();


                                //	System.out.println("when po num r more");

                                //	c3DataToMongo.setPurchaseOrderNumber(s);

                                //c3DataToMongo.setCurrent_WorkflowStateName_ID(Current_WorkFlow);

                                //c3DataToMongo.setSite_ExternalReference(d_format);
                                //	R9333LpvPoInterface check_if_PO_exists=r9333LpvPoInterfaceRepo.findBypurchaseOrderId(s.trim());
                                R9333LpvPoInterface check_if_PO_exists = r9333LpvPoInterfaceRepo.findByPurchaseOrderId(c3.getPurchaseOrderNumber());
                                if (check_if_PO_exists != null) {
                                    System.out.println("Id found ");
                                    break;
                                }
                                if (check_if_PO_exists == null || check_if_PO_exists.getProcessIndicator() == null || check_if_PO_exists.getIncoTerms1() == null) {
                                    continue;
                                }


                                System.out.print("IF po exists" + check_if_PO_exists.getPurchaseOrderId());
                                if (check_if_PO_exists != null) {

                                    if (check_if_PO_exists != null && check_if_PO_exists.getProcessIndicator().equals("") && (check_if_PO_exists.getIncoTerms1().equals("TMS2")
                                            || check_if_PO_exists.getIncoTerms1().equals("SDM") || check_if_PO_exists.getIncoTerms1().equals(""))) {
                                        File file = new File("/home/shivang/Documents/LCTFiles/C3Collection_" + i + ".csv");
                                        FileWriter outputfile = new FileWriter(file);
                                        List<String[]> data = new ArrayList<String[]>();
                                        CSVWriter writer = new CSVWriter(outputfile);

                                        if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) {
                                            SUB_State_Time = c3.getCustomDateTime01UTC();


                                            File file_deliveryPO = new File("/home/shivang/Documents/LCTFiles/C3Collection_DeliveryPO_" + c3.getPurchaseOrderNumber() + ".csv");
                                            FileWriter outputfile_deliveryPO = new FileWriter(file_deliveryPO);
                                            List<String[]> data_delivery_PO = new ArrayList<String[]>();
                                            CSVWriter writer_to_deliver_PO = new CSVWriter(outputfile_deliveryPO);

                                            data.clear();
                                            data.add(new String[]{"Delivery No", "Delivery Type", "Shipment Type", "Customer", "Supplier", "Operation Name", "ATA", "ATAC3"});
                                            writer_to_deliver_PO.writeAll(data);

                                            data_delivery_PO.add(new String[]{c3.getPurchaseOrderNumber(), "InboundDelivery", "InboundShipment", "Loblaw", check_if_PO_exists.getSupplierName(), "CreateDelivery", c3.getCustomDateTime01UTC(), c3.getCustomDateTime01UTC()});
                                            writer_to_deliver_PO.writeAll(data_delivery_PO);
                                            writer_to_deliver_PO.close();
                                            data_delivery_PO.clear();
                                            data.clear();


                                        } else if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door")) {
                                            SUB_State_Time = c3.getCustomDateTime02UTC();
                                        } else if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused")) {
                                            SUB_State_Time = c3.getCustomDateTime04UTC();
                                        }


                                        data.add(new String[]{"Order No", "Order Type", "Process Type", "Customer", "Supplier", "Operation Name", "UDF C3 Sub State", "Sub State Time", "Door Number"});
                                        writer.writeAll(data);


                                        //System.out.println("if found"+check_if_PO_exists);
                                        //flag_check_po=1;
                                        ///	C3DataComparision c3model=new C3DataComparision();
                                        String po_from_new_data = c3.getPurchaseOrderNumber();
                                        String Current_WorkflowStateName_ID = c3.getCurrent_WorkflowStateName_ID();
                                        String Site_ExternalReference = c3.getSite_ExternalReference();
                                        //String indicator=check_if_PO_exists.getIndicator();
                                        //	System.out.print("from other collection matching.. "+po_from_new_data + Current_WorkflowStateName_ID+ Site_ExternalReference +indicator);
                                        actual_data.add(new String[]{po_from_new_data, "standardPO", "supply", "Loblaw", check_if_PO_exists.getSupplierName(), "CreateOrder", Current_WorkflowStateName_ID, SUB_State_Time, c3.getCustomField05()});
                                        writer.writeAll(actual_data);
                                        writer.close();
                                        actual_data.clear();
                                        //writer.flush();
                                        i++;
                                    }
                                } else {
                                    continue;
                                }
                                //	mongoTemplate.save(c3DataToMongo);


                            }

                        }

                    }


                } else {
                    if (c3 != null) {
                        //System.out.println("inside else");
                        if (!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !c3.getSite_ExternalReference().trim().equals("")) {
                            if ((c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) || (c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door"))
                                    || (c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused"))) {
                                if (c3.getSite_ExternalReference().length() == 1) {
                                    String append_O = "0" + c3.getSite_ExternalReference();
                                    DO_format = "DO" + append_O;
                                } else if (c3.getSite_ExternalReference().length() == 2) {
                                    DO_format = "DO" + c3.getSite_ExternalReference();
                                }

//					for(String s: split_po) {
//						System.out.println(c3.getPurchaseOrderNumber() +" Current Workflow Id : "+c3.getCurrent_WorkflowStateName_ID()+ "Site_External Reference: " + DO_format);
//					}
                                //System.out.println("after all if");
                                if (!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !DO_format.trim().equals("")) {
                                    //	System.out.println("inside if after adding to file");

                                    //R9333LpvPoInterface check_if_PO_exists=r9333LpvPoInterfaceRepo.findBypurchaseOrderId(c3.getPurchaseOrderNumber());
                                    R9333LpvPoInterface check_if_PO_exists = r9333LpvPoInterfaceRepo.findByPurchaseOrderId(c3.getPurchaseOrderNumber());
                                    if (check_if_PO_exists == null) {
                                        System.out.println("Id found ");
                                        break;
                                    }
                                    System.out.print("IF po exists" + check_if_PO_exists.getPurchaseOrderId());

                                    if (check_if_PO_exists == null || check_if_PO_exists.getProcessIndicator() == null || check_if_PO_exists.getIncoTerms1() == null) {
                                        continue;
                                    }


                                    if (check_if_PO_exists != null) {
                                        if (check_if_PO_exists != null && check_if_PO_exists.getProcessIndicator().equals("")
                                                && (check_if_PO_exists.getIncoTerms1().equals("TMS2") ||
                                                check_if_PO_exists.getIncoTerms1().equals("SDM") || check_if_PO_exists.getIncoTerms1().equals(""))) {
                                            //flag_check_po=1;

                                            File file = new File("/home/shivang/Documents/LCTFiles/C3Collection_" + i + ".csv");
                                            FileWriter outputfile = new FileWriter(file);
                                            List<String[]> data = new ArrayList<String[]>();
                                            CSVWriter writer = new CSVWriter(outputfile);

                                            if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) {
                                                SUB_State_Time = c3.getCustomDateTime01UTC();


                                                File file_deliveryPO = new File("/home/shivang/Documents/LCTFiles/C3Collection_DeliveryPO_" + c3.getPurchaseOrderNumber() + ".csv");
                                                FileWriter outputfile_deliveryPO = new FileWriter(file_deliveryPO);
                                                List<String[]> data_delivery_PO = new ArrayList<String[]>();
                                                CSVWriter writer_to_deliver_PO = new CSVWriter(outputfile_deliveryPO);

                                                data.clear();
                                                data.add(new String[]{"Delivery No", "Delivery Type", "Shipment Type", "Customer", "Supplier", "Operation Name", "ATA", "ATAC3"});
                                                writer_to_deliver_PO.writeAll(data);

                                                data_delivery_PO.add(new String[]{c3.getPurchaseOrderNumber(), "InboundDelivery", "InboundShipment", "Loblaw", check_if_PO_exists.getSupplierName(), "CreateDelivery", c3.getCustomDateTime01UTC(), c3.getCustomDateTime01UTC()});
                                                writer_to_deliver_PO.writeAll(data_delivery_PO);
                                                writer_to_deliver_PO.close();
                                                data_delivery_PO.clear();
                                                data.clear();
                                            } else if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door")) {
                                                SUB_State_Time = c3.getCustomDateTime02UTC();
                                            } else if (c3.getCurrent_WorkflowStateName_ID() != null && c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused")) {
                                                SUB_State_Time = c3.getCustomDateTime04UTC();
                                            }
                                            data.add(new String[]{"Order No", "Order Type", "Process Type", "Customer", "Supplier", "Operation Name", "UDF C3 Sub State", "Sub State Time", "Door Number"});
                                            writer.writeAll(data);
                                            //System.out.println("if found"+check_if_PO_exists);

                                            String po_from_new_data = c3.getPurchaseOrderNumber();
                                            String Current_WorkflowStateName_ID = c3.getCurrent_WorkflowStateName_ID();
                                            String Site_ExternalReference = c3.getSite_ExternalReference();
                                            //String indicator=check_if_PO_exists.getIndicator();
                                            System.out.print("from other collection matching.." + po_from_new_data + Current_WorkflowStateName_ID + Site_ExternalReference + check_if_PO_exists.getSupplierName());
                                            //actual_data.add(new String[] {po_from_new_data,Current_WorkflowStateName_ID,Site_ExternalReference,indicator});
                                            actual_data.add(new String[]{po_from_new_data, "standardPO", "supply", "Loblaw", check_if_PO_exists.getSupplierName(), "CreateOrder", Current_WorkflowStateName_ID, SUB_State_Time, c3.getCustomField05()});
                                            writer.writeAll(actual_data);
                                            writer.close();
                                            actual_data.clear();
                                            //writer.flush();
                                            i++;
                                            //c3DataToMongo.setPurchaseOrderNumber(c3.getPurchaseOrderNumber());
                                            //c3DataToMongo.setCurrent_WorkflowStateName_ID(c3.getCurrent_WorkflowStateName_ID());
                                            //c3DataToMongo.setSite_ExternalReference(DO_format);
                                            //	System.out.println("from c3datatomongo "+c3DataToMongo);
                                            //mongoTemplate.save(c3DataToMongo);

                                        }
                                    } else {
                                        continue;
                                    }


                                }

                            }
                        }
                    }
                }
            }


        }

    }
}


















































