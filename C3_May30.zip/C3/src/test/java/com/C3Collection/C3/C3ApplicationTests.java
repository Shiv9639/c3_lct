package com.C3Collection.C3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
