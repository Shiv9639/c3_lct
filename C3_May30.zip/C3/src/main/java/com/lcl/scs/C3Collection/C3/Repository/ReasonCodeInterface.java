package com.C3Collection.C3.Repository;

import com.C3Collection.C3.Model.R9333LpvPoInterface;
import com.C3Collection.C3.Model.ReasonCodeMaster;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReasonCodeInterface extends MongoRepository<ReasonCodeMaster, String> {

}
