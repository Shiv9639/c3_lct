package com.C3Collection.C3.Model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="C3_Test")
public class C3Master {

    @Id
    private String id;
    private String Carrier_ID;
    private String comment;
    private String completed;
    private String CountInteger01;
    private String CountInteger02;
    private String CountInteger03;
    private String CountIntegerOverridden01;
    private String CountIntegerOverridden02;
    private String CustomDuration01;
    private String CustomField01;
    private String CustomField02;
    private String CustomField04;
    private String CustomField18;
    private String CustomField32;
    private String CustomField33;
    private String Discarded;
    private String Executing;
    private String ExternalReference;
    private String Faulty;
    private String IsAvailabilityInWindow;
    private String IsCheckedIn;
    private String IsOnSite;
    private String IsRequestedOutsideWindow;
    private String LastActionTimeStampUTC;
    private String Last_WorkflowTransitionName_ID;
    private String LineCount;
    private String MasterReferenceNumber;
    private String Prev_WorkflowStateName_ID;
    private String ReferenceNumber;
    private String RequestedDateUTC;
    private String RequestedDuration;
    private String RequestedWarehouse_ExternalRefer;
    private String ReservationId;
    private String ReservationUser_ID_LastAction;
    private String ReservationUser_ID_StatedBy01;
    private String ReservationUser_ID_StatedBy02;
    private String ReservationUser_ID_StatedBy03;
    private String ReservationUser_ID_StatedBy04;
    private String ReservationUser_ID_StatedBy05;
    private String ReservationUser_ID_StatedBy06;
    private String ReservationUser_ID_StatedBy08;
    private String ReservationUser_ID_StatedBy11;
    private String ReservationUser_ID_StatedBy12;
    private String ReservationUser_ID_WorkflowCurre;
    private String ScheduledDateUTC;
    private String StandingAppointmentName;
    private String StatedTimestamp01UTC;
    private String StatedTimestamp02UTC;
    private String StatedTimestamp03UTC;
    private String StatedTimestamp04UTC;
    private String StatedTimestamp05UTC;
    private String StatedTimestamp06UTC;
    private String StatedTimestamp08UTC;
    private String StatedTimestamp11UTC;
    private String StatedTimestamp12UTC;
    private String SubWarehouse_ExternalReference;
    private String SupplierAccount_ID;
    private String Supplier_ID;
    private String Supplier_ID_Summary;
    private String TD_LOAD_DT;
    private String Tag01_ExternalReference;
    private String Tag03_ExternalReference;
    private String Tag15_ExternalReference;
    private String Tag20_ExternalReference;
    private String Unplanned;
    private String Warehouse_ExternalReference;
    private String WorkflowId;
    private String WorkflowId_WorkflowDockExecution;
    private String WorkflowId_WorkflowReservation;
    private String WorkflowId_WorkflowTruckAndDrive;
    private String WorkflowId_WorkflowVehicleData;
    private String WorkflowId_WorkflowVehicleExecut;
    private String WorkflowId_WorkflowVehicleMoveme;
    private String WorkflowId_WorkflowVehicleSpot;
    private String WorkflowId_WorkflowWorkerExecuti;
    private String WorkflowType_ExternalReference;
    private String CustomField05;
    private String CustomField15;
    private String Site_ExternalReference;
    private String CustomDateTime01UTC;//arrival
    private String CustomDateTime02UTC;//in door
    private String CustomDateTime03UTC;
    private String CustomDateTime04UTC;//refused
    private String PurchaseOrderNumber;
    private String Current_WorkflowStateName_ID;

    public C3Master() {
        // TODO Auto-generated constructor stub
    }



    public C3Master(String id, String carrier_ID, String comment, String completed, String countInteger01,
                    String countInteger02, String countInteger03, String countIntegerOverridden01,
                    String countIntegerOverridden02, String customDuration01, String customField01, String customField02,
                    String customField04, String customField18, String customField32, String customField33, String discarded,
                    String executing, String externalReference, String faulty, String isAvailabilityInWindow,
                    String isCheckedIn, String isOnSite, String isRequestedOutsideWindow, String lastActionTimeStampUTC,
                    String last_WorkflowTransitionName_ID, String lineCount, String masterReferenceNumber,
                    String prev_WorkflowStateName_ID, String referenceNumber, String requestedDateUTC, String requestedDuration,
                    String requestedWarehouse_ExternalRefer, String reservationId, String reservationUser_ID_LastAction,
                    String reservationUser_ID_StatedBy01, String reservationUser_ID_StatedBy02,
                    String reservationUser_ID_StatedBy03, String reservationUser_ID_StatedBy04,
                    String reservationUser_ID_StatedBy05, String reservationUser_ID_StatedBy06,
                    String reservationUser_ID_StatedBy08, String reservationUser_ID_StatedBy11,
                    String reservationUser_ID_StatedBy12, String reservationUser_ID_WorkflowCurre, String scheduledDateUTC,
                    String standingAppointmentName, String statedTimestamp01UTC, String statedTimestamp02UTC,
                    String statedTimestamp03UTC, String statedTimestamp04UTC, String statedTimestamp05UTC,
                    String statedTimestamp06UTC, String statedTimestamp08UTC, String statedTimestamp11UTC,
                    String statedTimestamp12UTC, String subWarehouse_ExternalReference, String supplierAccount_ID,
                    String supplier_ID, String supplier_ID_Summary, String tD_LOAD_DT, String tag01_ExternalReference,
                    String tag03_ExternalReference, String tag15_ExternalReference, String tag20_ExternalReference,
                    String unplanned, String warehouse_ExternalReference, String workflowId,
                    String workflowId_WorkflowDockExecution, String workflowId_WorkflowReservation,
                    String workflowId_WorkflowTruckAndDrive, String workflowId_WorkflowVehicleData,
                    String workflowId_WorkflowVehicleExecut, String workflowId_WorkflowVehicleMoveme,
                    String workflowId_WorkflowVehicleSpot, String workflowId_WorkflowWorkerExecuti,
                    String workflowType_ExternalReference, String customField05, String customField15,
                    String site_ExternalReference, String customDateTime01UTC, String customDateTime02UTC,
                    String customDateTime03UTC, String customDateTime04UTC, String purchaseOrderNumber,
                    String current_WorkflowStateName_ID) {
        super();
        this.id = id;
        Carrier_ID = carrier_ID;
        this.comment = comment;
        this.completed = completed;
        CountInteger01 = countInteger01;
        CountInteger02 = countInteger02;
        CountInteger03 = countInteger03;
        CountIntegerOverridden01 = countIntegerOverridden01;
        CountIntegerOverridden02 = countIntegerOverridden02;
        CustomDuration01 = customDuration01;
        CustomField01 = customField01;
        CustomField02 = customField02;
        CustomField04 = customField04;
        CustomField18 = customField18;
        CustomField32 = customField32;
        CustomField33 = customField33;
        Discarded = discarded;
        Executing = executing;
        ExternalReference = externalReference;
        Faulty = faulty;
        IsAvailabilityInWindow = isAvailabilityInWindow;
        IsCheckedIn = isCheckedIn;
        IsOnSite = isOnSite;
        IsRequestedOutsideWindow = isRequestedOutsideWindow;
        LastActionTimeStampUTC = lastActionTimeStampUTC;
        Last_WorkflowTransitionName_ID = last_WorkflowTransitionName_ID;
        LineCount = lineCount;
        MasterReferenceNumber = masterReferenceNumber;
        Prev_WorkflowStateName_ID = prev_WorkflowStateName_ID;
        ReferenceNumber = referenceNumber;
        RequestedDateUTC = requestedDateUTC;
        RequestedDuration = requestedDuration;
        RequestedWarehouse_ExternalRefer = requestedWarehouse_ExternalRefer;
        ReservationId = reservationId;
        ReservationUser_ID_LastAction = reservationUser_ID_LastAction;
        ReservationUser_ID_StatedBy01 = reservationUser_ID_StatedBy01;
        ReservationUser_ID_StatedBy02 = reservationUser_ID_StatedBy02;
        ReservationUser_ID_StatedBy03 = reservationUser_ID_StatedBy03;
        ReservationUser_ID_StatedBy04 = reservationUser_ID_StatedBy04;
        ReservationUser_ID_StatedBy05 = reservationUser_ID_StatedBy05;
        ReservationUser_ID_StatedBy06 = reservationUser_ID_StatedBy06;
        ReservationUser_ID_StatedBy08 = reservationUser_ID_StatedBy08;
        ReservationUser_ID_StatedBy11 = reservationUser_ID_StatedBy11;
        ReservationUser_ID_StatedBy12 = reservationUser_ID_StatedBy12;
        ReservationUser_ID_WorkflowCurre = reservationUser_ID_WorkflowCurre;
        ScheduledDateUTC = scheduledDateUTC;
        StandingAppointmentName = standingAppointmentName;
        StatedTimestamp01UTC = statedTimestamp01UTC;
        StatedTimestamp02UTC = statedTimestamp02UTC;
        StatedTimestamp03UTC = statedTimestamp03UTC;
        StatedTimestamp04UTC = statedTimestamp04UTC;
        StatedTimestamp05UTC = statedTimestamp05UTC;
        StatedTimestamp06UTC = statedTimestamp06UTC;
        StatedTimestamp08UTC = statedTimestamp08UTC;
        StatedTimestamp11UTC = statedTimestamp11UTC;
        StatedTimestamp12UTC = statedTimestamp12UTC;
        SubWarehouse_ExternalReference = subWarehouse_ExternalReference;
        SupplierAccount_ID = supplierAccount_ID;
        Supplier_ID = supplier_ID;
        Supplier_ID_Summary = supplier_ID_Summary;
        TD_LOAD_DT = tD_LOAD_DT;
        Tag01_ExternalReference = tag01_ExternalReference;
        Tag03_ExternalReference = tag03_ExternalReference;
        Tag15_ExternalReference = tag15_ExternalReference;
        Tag20_ExternalReference = tag20_ExternalReference;
        Unplanned = unplanned;
        Warehouse_ExternalReference = warehouse_ExternalReference;
        WorkflowId = workflowId;
        WorkflowId_WorkflowDockExecution = workflowId_WorkflowDockExecution;
        WorkflowId_WorkflowReservation = workflowId_WorkflowReservation;
        WorkflowId_WorkflowTruckAndDrive = workflowId_WorkflowTruckAndDrive;
        WorkflowId_WorkflowVehicleData = workflowId_WorkflowVehicleData;
        WorkflowId_WorkflowVehicleExecut = workflowId_WorkflowVehicleExecut;
        WorkflowId_WorkflowVehicleMoveme = workflowId_WorkflowVehicleMoveme;
        WorkflowId_WorkflowVehicleSpot = workflowId_WorkflowVehicleSpot;
        WorkflowId_WorkflowWorkerExecuti = workflowId_WorkflowWorkerExecuti;
        WorkflowType_ExternalReference = workflowType_ExternalReference;
        CustomField05 = customField05;
        CustomField15 = customField15;
        Site_ExternalReference = site_ExternalReference;
        CustomDateTime01UTC = customDateTime01UTC;
        CustomDateTime02UTC = customDateTime02UTC;
        CustomDateTime03UTC = customDateTime03UTC;
        CustomDateTime04UTC = customDateTime04UTC;
        PurchaseOrderNumber = purchaseOrderNumber;
        Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCarrier_ID() {
        return Carrier_ID;
    }

    public void setCarrier_ID(String carrier_ID) {
        Carrier_ID = carrier_ID;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCompleted() {
        return completed;
    }

    public void setCompleted(String completed) {
        this.completed = completed;
    }

    public String getCountInteger01() {
        return CountInteger01;
    }

    public void setCountInteger01(String countInteger01) {
        CountInteger01 = countInteger01;
    }

    public String getCountInteger02() {
        return CountInteger02;
    }

    public void setCountInteger02(String countInteger02) {
        CountInteger02 = countInteger02;
    }

    public String getCountInteger03() {
        return CountInteger03;
    }

    public void setCountInteger03(String countInteger03) {
        CountInteger03 = countInteger03;
    }

    public String getCountIntegerOverridden01() {
        return CountIntegerOverridden01;
    }

    public void setCountIntegerOverridden01(String countIntegerOverridden01) {
        CountIntegerOverridden01 = countIntegerOverridden01;
    }

    public String getCountIntegerOverridden02() {
        return CountIntegerOverridden02;
    }

    public void setCountIntegerOverridden02(String countIntegerOverridden02) {
        CountIntegerOverridden02 = countIntegerOverridden02;
    }

    public String getCustomDuration01() {
        return CustomDuration01;
    }

    public void setCustomDuration01(String customDuration01) {
        CustomDuration01 = customDuration01;
    }

    public String getCustomField01() {
        return CustomField01;
    }

    public void setCustomField01(String customField01) {
        CustomField01 = customField01;
    }

    public String getCustomField02() {
        return CustomField02;
    }

    public void setCustomField02(String customField02) {
        CustomField02 = customField02;
    }

    public String getCustomField04() {
        return CustomField04;
    }

    public void setCustomField04(String customField04) {
        CustomField04 = customField04;
    }

    public String getCustomField18() {
        return CustomField18;
    }

    public void setCustomField18(String customField18) {
        CustomField18 = customField18;
    }

    public String getCustomField32() {
        return CustomField32;
    }

    public void setCustomField32(String customField32) {
        CustomField32 = customField32;
    }

    public String getCustomField33() {
        return CustomField33;
    }

    public void setCustomField33(String customField33) {
        CustomField33 = customField33;
    }

    public String getDiscarded() {
        return Discarded;
    }

    public void setDiscarded(String discarded) {
        Discarded = discarded;
    }

    public String getExecuting() {
        return Executing;
    }

    public void setExecuting(String executing) {
        Executing = executing;
    }

    public String getExternalReference() {
        return ExternalReference;
    }

    public void setExternalReference(String externalReference) {
        ExternalReference = externalReference;
    }

    public String getFaulty() {
        return Faulty;
    }

    public void setFaulty(String faulty) {
        Faulty = faulty;
    }

    public String getIsAvailabilityInWindow() {
        return IsAvailabilityInWindow;
    }

    public void setIsAvailabilityInWindow(String isAvailabilityInWindow) {
        IsAvailabilityInWindow = isAvailabilityInWindow;
    }

    public String getIsCheckedIn() {
        return IsCheckedIn;
    }

    public void setIsCheckedIn(String isCheckedIn) {
        IsCheckedIn = isCheckedIn;
    }

    public String getIsOnSite() {
        return IsOnSite;
    }

    public void setIsOnSite(String isOnSite) {
        IsOnSite = isOnSite;
    }

    public String getIsRequestedOutsideWindow() {
        return IsRequestedOutsideWindow;
    }

    public void setIsRequestedOutsideWindow(String isRequestedOutsideWindow) {
        IsRequestedOutsideWindow = isRequestedOutsideWindow;
    }

    public String getLastActionTimeStampUTC() {
        return LastActionTimeStampUTC;
    }

    public void setLastActionTimeStampUTC(String lastActionTimeStampUTC) {
        LastActionTimeStampUTC = lastActionTimeStampUTC;
    }

    public String getLast_WorkflowTransitionName_ID() {
        return Last_WorkflowTransitionName_ID;
    }

    public void setLast_WorkflowTransitionName_ID(String last_WorkflowTransitionName_ID) {
        Last_WorkflowTransitionName_ID = last_WorkflowTransitionName_ID;
    }

    public String getLineCount() {
        return LineCount;
    }

    public void setLineCount(String lineCount) {
        LineCount = lineCount;
    }

    public String getMasterReferenceNumber() {
        return MasterReferenceNumber;
    }

    public void setMasterReferenceNumber(String masterReferenceNumber) {
        MasterReferenceNumber = masterReferenceNumber;
    }

    public String getPrev_WorkflowStateName_ID() {
        return Prev_WorkflowStateName_ID;
    }

    public void setPrev_WorkflowStateName_ID(String prev_WorkflowStateName_ID) {
        Prev_WorkflowStateName_ID = prev_WorkflowStateName_ID;
    }

    public String getReferenceNumber() {
        return ReferenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        ReferenceNumber = referenceNumber;
    }

    public String getRequestedDateUTC() {
        return RequestedDateUTC;
    }

    public void setRequestedDateUTC(String requestedDateUTC) {
        RequestedDateUTC = requestedDateUTC;
    }

    public String getRequestedDuration() {
        return RequestedDuration;
    }

    public void setRequestedDuration(String requestedDuration) {
        RequestedDuration = requestedDuration;
    }

    public String getRequestedWarehouse_ExternalRefer() {
        return RequestedWarehouse_ExternalRefer;
    }

    public void setRequestedWarehouse_ExternalRefer(String requestedWarehouse_ExternalRefer) {
        RequestedWarehouse_ExternalRefer = requestedWarehouse_ExternalRefer;
    }

    public String getReservationId() {
        return ReservationId;
    }

    public void setReservationId(String reservationId) {
        ReservationId = reservationId;
    }

    public String getReservationUser_ID_LastAction() {
        return ReservationUser_ID_LastAction;
    }

    public void setReservationUser_ID_LastAction(String reservationUser_ID_LastAction) {
        ReservationUser_ID_LastAction = reservationUser_ID_LastAction;
    }

    public String getReservationUser_ID_StatedBy01() {
        return ReservationUser_ID_StatedBy01;
    }

    public void setReservationUser_ID_StatedBy01(String reservationUser_ID_StatedBy01) {
        ReservationUser_ID_StatedBy01 = reservationUser_ID_StatedBy01;
    }

    public String getReservationUser_ID_StatedBy02() {
        return ReservationUser_ID_StatedBy02;
    }

    public void setReservationUser_ID_StatedBy02(String reservationUser_ID_StatedBy02) {
        ReservationUser_ID_StatedBy02 = reservationUser_ID_StatedBy02;
    }

    public String getReservationUser_ID_StatedBy03() {
        return ReservationUser_ID_StatedBy03;
    }

    public void setReservationUser_ID_StatedBy03(String reservationUser_ID_StatedBy03) {
        ReservationUser_ID_StatedBy03 = reservationUser_ID_StatedBy03;
    }

    public String getReservationUser_ID_StatedBy04() {
        return ReservationUser_ID_StatedBy04;
    }

    public void setReservationUser_ID_StatedBy04(String reservationUser_ID_StatedBy04) {
        ReservationUser_ID_StatedBy04 = reservationUser_ID_StatedBy04;
    }

    public String getReservationUser_ID_StatedBy05() {
        return ReservationUser_ID_StatedBy05;
    }

    public void setReservationUser_ID_StatedBy05(String reservationUser_ID_StatedBy05) {
        ReservationUser_ID_StatedBy05 = reservationUser_ID_StatedBy05;
    }

    public String getReservationUser_ID_StatedBy06() {
        return ReservationUser_ID_StatedBy06;
    }

    public void setReservationUser_ID_StatedBy06(String reservationUser_ID_StatedBy06) {
        ReservationUser_ID_StatedBy06 = reservationUser_ID_StatedBy06;
    }

    public String getReservationUser_ID_StatedBy08() {
        return ReservationUser_ID_StatedBy08;
    }

    public void setReservationUser_ID_StatedBy08(String reservationUser_ID_StatedBy08) {
        ReservationUser_ID_StatedBy08 = reservationUser_ID_StatedBy08;
    }

    public String getReservationUser_ID_StatedBy11() {
        return ReservationUser_ID_StatedBy11;
    }

    public void setReservationUser_ID_StatedBy11(String reservationUser_ID_StatedBy11) {
        ReservationUser_ID_StatedBy11 = reservationUser_ID_StatedBy11;
    }

    public String getReservationUser_ID_StatedBy12() {
        return ReservationUser_ID_StatedBy12;
    }

    public void setReservationUser_ID_StatedBy12(String reservationUser_ID_StatedBy12) {
        ReservationUser_ID_StatedBy12 = reservationUser_ID_StatedBy12;
    }

    public String getReservationUser_ID_WorkflowCurre() {
        return ReservationUser_ID_WorkflowCurre;
    }

    public void setReservationUser_ID_WorkflowCurre(String reservationUser_ID_WorkflowCurre) {
        ReservationUser_ID_WorkflowCurre = reservationUser_ID_WorkflowCurre;
    }

    public String getScheduledDateUTC() {
        return ScheduledDateUTC;
    }

    public void setScheduledDateUTC(String scheduledDateUTC) {
        ScheduledDateUTC = scheduledDateUTC;
    }

    public String getStandingAppointmentName() {
        return StandingAppointmentName;
    }

    public void setStandingAppointmentName(String standingAppointmentName) {
        StandingAppointmentName = standingAppointmentName;
    }

    public String getStatedTimestamp01UTC() {
        return StatedTimestamp01UTC;
    }

    public void setStatedTimestamp01UTC(String statedTimestamp01UTC) {
        StatedTimestamp01UTC = statedTimestamp01UTC;
    }

    public String getStatedTimestamp02UTC() {
        return StatedTimestamp02UTC;
    }

    public void setStatedTimestamp02UTC(String statedTimestamp02UTC) {
        StatedTimestamp02UTC = statedTimestamp02UTC;
    }

    public String getStatedTimestamp03UTC() {
        return StatedTimestamp03UTC;
    }

    public void setStatedTimestamp03UTC(String statedTimestamp03UTC) {
        StatedTimestamp03UTC = statedTimestamp03UTC;
    }

    public String getStatedTimestamp04UTC() {
        return StatedTimestamp04UTC;
    }

    public void setStatedTimestamp04UTC(String statedTimestamp04UTC) {
        StatedTimestamp04UTC = statedTimestamp04UTC;
    }

    public String getStatedTimestamp05UTC() {
        return StatedTimestamp05UTC;
    }

    public void setStatedTimestamp05UTC(String statedTimestamp05UTC) {
        StatedTimestamp05UTC = statedTimestamp05UTC;
    }

    public String getStatedTimestamp06UTC() {
        return StatedTimestamp06UTC;
    }

    public void setStatedTimestamp06UTC(String statedTimestamp06UTC) {
        StatedTimestamp06UTC = statedTimestamp06UTC;
    }

    public String getStatedTimestamp08UTC() {
        return StatedTimestamp08UTC;
    }

    public void setStatedTimestamp08UTC(String statedTimestamp08UTC) {
        StatedTimestamp08UTC = statedTimestamp08UTC;
    }

    public String getStatedTimestamp11UTC() {
        return StatedTimestamp11UTC;
    }

    public void setStatedTimestamp11UTC(String statedTimestamp11UTC) {
        StatedTimestamp11UTC = statedTimestamp11UTC;
    }

    public String getStatedTimestamp12UTC() {
        return StatedTimestamp12UTC;
    }

    public void setStatedTimestamp12UTC(String statedTimestamp12UTC) {
        StatedTimestamp12UTC = statedTimestamp12UTC;
    }

    public String getSubWarehouse_ExternalReference() {
        return SubWarehouse_ExternalReference;
    }

    public void setSubWarehouse_ExternalReference(String subWarehouse_ExternalReference) {
        SubWarehouse_ExternalReference = subWarehouse_ExternalReference;
    }

    public String getSupplierAccount_ID() {
        return SupplierAccount_ID;
    }

    public void setSupplierAccount_ID(String supplierAccount_ID) {
        SupplierAccount_ID = supplierAccount_ID;
    }

    public String getSupplier_ID() {
        return Supplier_ID;
    }

    public void setSupplier_ID(String supplier_ID) {
        Supplier_ID = supplier_ID;
    }

    public String getSupplier_ID_Summary() {
        return Supplier_ID_Summary;
    }

    public void setSupplier_ID_Summary(String supplier_ID_Summary) {
        Supplier_ID_Summary = supplier_ID_Summary;
    }

    public String getTD_LOAD_DT() {
        return TD_LOAD_DT;
    }

    public void setTD_LOAD_DT(String tD_LOAD_DT) {
        TD_LOAD_DT = tD_LOAD_DT;
    }

    public String getTag01_ExternalReference() {
        return Tag01_ExternalReference;
    }

    public void setTag01_ExternalReference(String tag01_ExternalReference) {
        Tag01_ExternalReference = tag01_ExternalReference;
    }

    public String getTag03_ExternalReference() {
        return Tag03_ExternalReference;
    }

    public void setTag03_ExternalReference(String tag03_ExternalReference) {
        Tag03_ExternalReference = tag03_ExternalReference;
    }

    public String getTag15_ExternalReference() {
        return Tag15_ExternalReference;
    }

    public void setTag15_ExternalReference(String tag15_ExternalReference) {
        Tag15_ExternalReference = tag15_ExternalReference;
    }

    public String getTag20_ExternalReference() {
        return Tag20_ExternalReference;
    }

    public void setTag20_ExternalReference(String tag20_ExternalReference) {
        Tag20_ExternalReference = tag20_ExternalReference;
    }

    public String getUnplanned() {
        return Unplanned;
    }

    public void setUnplanned(String unplanned) {
        Unplanned = unplanned;
    }

    public String getWarehouse_ExternalReference() {
        return Warehouse_ExternalReference;
    }

    public void setWarehouse_ExternalReference(String warehouse_ExternalReference) {
        Warehouse_ExternalReference = warehouse_ExternalReference;
    }

    public String getWorkflowId() {
        return WorkflowId;
    }

    public void setWorkflowId(String workflowId) {
        WorkflowId = workflowId;
    }

    public String getWorkflowId_WorkflowDockExecution() {
        return WorkflowId_WorkflowDockExecution;
    }

    public void setWorkflowId_WorkflowDockExecution(String workflowId_WorkflowDockExecution) {
        WorkflowId_WorkflowDockExecution = workflowId_WorkflowDockExecution;
    }

    public String getWorkflowId_WorkflowReservation() {
        return WorkflowId_WorkflowReservation;
    }

    public void setWorkflowId_WorkflowReservation(String workflowId_WorkflowReservation) {
        WorkflowId_WorkflowReservation = workflowId_WorkflowReservation;
    }

    public String getWorkflowId_WorkflowTruckAndDrive() {
        return WorkflowId_WorkflowTruckAndDrive;
    }

    public void setWorkflowId_WorkflowTruckAndDrive(String workflowId_WorkflowTruckAndDrive) {
        WorkflowId_WorkflowTruckAndDrive = workflowId_WorkflowTruckAndDrive;
    }

    public String getWorkflowId_WorkflowVehicleData() {
        return WorkflowId_WorkflowVehicleData;
    }

    public void setWorkflowId_WorkflowVehicleData(String workflowId_WorkflowVehicleData) {
        WorkflowId_WorkflowVehicleData = workflowId_WorkflowVehicleData;
    }

    public String getWorkflowId_WorkflowVehicleExecut() {
        return WorkflowId_WorkflowVehicleExecut;
    }

    public void setWorkflowId_WorkflowVehicleExecut(String workflowId_WorkflowVehicleExecut) {
        WorkflowId_WorkflowVehicleExecut = workflowId_WorkflowVehicleExecut;
    }

    public String getWorkflowId_WorkflowVehicleMoveme() {
        return WorkflowId_WorkflowVehicleMoveme;
    }

    public void setWorkflowId_WorkflowVehicleMoveme(String workflowId_WorkflowVehicleMoveme) {
        WorkflowId_WorkflowVehicleMoveme = workflowId_WorkflowVehicleMoveme;
    }

    public String getWorkflowId_WorkflowVehicleSpot() {
        return WorkflowId_WorkflowVehicleSpot;
    }

    public void setWorkflowId_WorkflowVehicleSpot(String workflowId_WorkflowVehicleSpot) {
        WorkflowId_WorkflowVehicleSpot = workflowId_WorkflowVehicleSpot;
    }

    public String getWorkflowId_WorkflowWorkerExecuti() {
        return WorkflowId_WorkflowWorkerExecuti;
    }

    public void setWorkflowId_WorkflowWorkerExecuti(String workflowId_WorkflowWorkerExecuti) {
        WorkflowId_WorkflowWorkerExecuti = workflowId_WorkflowWorkerExecuti;
    }

    public String getWorkflowType_ExternalReference() {
        return WorkflowType_ExternalReference;
    }

    public void setWorkflowType_ExternalReference(String workflowType_ExternalReference) {
        WorkflowType_ExternalReference = workflowType_ExternalReference;
    }

    public String getCustomField05() {
        return CustomField05;
    }

    public void setCustomField05(String customField05) {
        CustomField05 = customField05;
    }

    public String getCustomField15() {
        return CustomField15;
    }

    public void setCustomField15(String customField15) {
        CustomField15 = customField15;
    }

    public String getSite_ExternalReference() {
        return Site_ExternalReference;
    }

    public void setSite_ExternalReference(String site_ExternalReference) {
        Site_ExternalReference = site_ExternalReference;
    }

    public String getCustomDateTime01UTC() {
        return CustomDateTime01UTC;
    }

    public void setCustomDateTime01UTC(String customDateTime01UTC) {
        CustomDateTime01UTC = customDateTime01UTC;
    }

    public String getCustomDateTime02UTC() {
        return CustomDateTime02UTC;
    }

    public void setCustomDateTime02UTC(String customDateTime02UTC) {
        CustomDateTime02UTC = customDateTime02UTC;
    }

    public String getCustomDateTime03UTC() {
        return CustomDateTime03UTC;
    }

    public void setCustomDateTime03UTC(String customDateTime03UTC) {
        CustomDateTime03UTC = customDateTime03UTC;
    }

    public String getCustomDateTime04UTC() {
        return CustomDateTime04UTC;
    }

    public void setCustomDateTime04UTC(String customDateTime04UTC) {
        CustomDateTime04UTC = customDateTime04UTC;
    }

    public String getPurchaseOrderNumber() {
        return PurchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        PurchaseOrderNumber = purchaseOrderNumber;
    }

    public String getCurrent_WorkflowStateName_ID() {
        return Current_WorkflowStateName_ID;
    }

    public void setCurrent_WorkflowStateName_ID(String current_WorkflowStateName_ID) {
        Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
    }

}