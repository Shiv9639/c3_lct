package com.C3Collection.C3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class C3Application {

	public static void main(String[] args) {
		SpringApplication.run(C3Application.class, args);
	}
}
