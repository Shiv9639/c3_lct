package com.C3Collection.C3.Model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "C3_Test")
public class DatFileReader {
}
