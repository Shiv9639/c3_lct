
package com.example.demo;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.opencsv.CSVWriter;

@SpringBootApplication
public class DemoApplication  implements CommandLineRunner{

	@Autowired
	private C3DataToMongRepo senddatatomongo;
	@Autowired
	private C3MasterRepo repository;
	@Autowired
	private C3DataComaprisionRepo c3DataComparisionRepo;
	

	@Autowired
	private MongoTemplate  mongoTemplate;
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		List<C3Master> l= repository.findAll();
		int flag_check_po=0;
		List<String> po=new ArrayList<>();
		File file = new File("/home/shivang/Documents/C3Collection.csv");
		FileWriter outputfile = new FileWriter(file);
		List<String[]> data = new ArrayList<String[]>();
        CSVWriter writer = new CSVWriter(outputfile);
		String DO_format="";
		data.add(new String[] {"PO Number", "Current_WorkflowStateName_ID", "Site_ExternalReference" });
		writer.writeAll(data);
		List<String[]> actual_data = new ArrayList<String[]>();
			
		for(C3Master c3: l) {
			flag_check_po=0;
			if(c3!=null) {
				C3DataToMongo c3DataToMongo=new C3DataToMongo();
				String po_no=c3.getPurchaseOrderNumber();
				String[] split_po=po_no.split(",");
				
				if((split_po.length)>1){
					if(!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !c3.getSite_ExternalReference().trim().equals("")) 
					{
						if((c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) || (c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door")) 

								|| (c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused"))){
								if(c3.getSite_ExternalReference().length()==1) {
									String append_O= "0"+c3.getSite_ExternalReference();
									 DO_format="DO"+append_O;
								}
								
								else if(c3.getSite_ExternalReference().length()==2) {
									DO_format="DO"+c3.getSite_ExternalReference();
									}
								
							
							String Current_WorkFlow=c3.getCurrent_WorkflowStateName_ID();
							String d_format=DO_format;
							for(String s: split_po) {
								flag_check_po=0;
								c3DataToMongo=new C3DataToMongo();
								
								
								
								try {
									
							//	System.out.println("when po num r more");
								
								c3DataToMongo.setPurchaseOrderNumber(s);
								
								c3DataToMongo.setCurrent_WorkflowStateName_ID(Current_WorkFlow);
								
								c3DataToMongo.setSite_ExternalReference(d_format);
								C3DataComparision check_if_PO_exists=c3DataComparisionRepo.findByPurchaseOrderNumber(s.trim());
								
								//System.out.print("IF po exists"+check_if_PO_exists);
								if(check_if_PO_exists!=null) {
									//System.out.println("if found"+check_if_PO_exists);
									flag_check_po=1;
									C3DataComparision c3model=new C3DataComparision();
									String po_from_new_data=c3.getPurchaseOrderNumber();
									String Current_WorkflowStateName_ID=c3.getCurrent_WorkflowStateName_ID();
									String Site_ExternalReference=c3.getSite_ExternalReference();
									String indicator=check_if_PO_exists.getIndicator();
								//	System.out.print("from other collection matching.. "+po_from_new_data + Current_WorkflowStateName_ID+ Site_ExternalReference +indicator);
									actual_data.add(new String[] {po_from_new_data,Current_WorkflowStateName_ID,Site_ExternalReference, indicator});
								
								}
								if(flag_check_po==0) {
									actual_data.add(new String[] {s, Current_WorkFlow, d_format} );
								}
								mongoTemplate.save(c3DataToMongo);
								}catch(Exception e) { System.out.println(e);}
								
							}
						
					}
						
					}	
					
					
		}
	else
		{
		if(c3!=null) {
			//System.out.println("inside else");
			if(!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !c3.getSite_ExternalReference().trim().equals("")) 
			{
				if((c3.getCurrent_WorkflowStateName_ID().trim().equals("Arrived")) || (c3.getCurrent_WorkflowStateName_ID().trim().equals("In Door")) 
						|| (c3.getCurrent_WorkflowStateName_ID().trim().equals("Refused"))){
					if(c3.getSite_ExternalReference().length()==1) {
						String append_O= "0"+c3.getSite_ExternalReference();
						 DO_format="DO"+append_O;
					}
					
					else if(c3.getSite_ExternalReference().length()==2) {
						DO_format="DO"+c3.getSite_ExternalReference();
						}
					
//					for(String s: split_po) {
//						System.out.println(c3.getPurchaseOrderNumber() +" Current Workflow Id : "+c3.getCurrent_WorkflowStateName_ID()+ "Site_External Reference: " + DO_format);
//					}
					//System.out.println("after all if");
					if(!c3.getPurchaseOrderNumber().trim().equals("") && !c3.getCurrent_WorkflowStateName_ID().trim().equals("") && !DO_format.trim().equals("")) 
					{
					//	System.out.println("inside if after adding to file");
					try {	
						
						C3DataComparision check_if_PO_exists=c3DataComparisionRepo.findByPurchaseOrderNumber(c3.getPurchaseOrderNumber().trim());
						//System.out.print("IF po exists"+check_if_PO_exists);
						if(check_if_PO_exists!=null) {
							flag_check_po=1;
							System.out.println("if found"+check_if_PO_exists);

							C3DataComparision c3model=new C3DataComparision();
							String po_from_new_data=c3.getPurchaseOrderNumber();
							String Current_WorkflowStateName_ID=c3.getCurrent_WorkflowStateName_ID();
							String Site_ExternalReference=c3.getSite_ExternalReference();
							String indicator=check_if_PO_exists.getIndicator();
					        System.out.print("from other collection matching.."+po_from_new_data + Current_WorkflowStateName_ID+ Site_ExternalReference+indicator);
							actual_data.add(new String[] {po_from_new_data,Current_WorkflowStateName_ID,Site_ExternalReference,indicator});
						}
						if(flag_check_po==0) {
						actual_data.add(new String[] {c3.getPurchaseOrderNumber(), c3.getCurrent_WorkflowStateName_ID(), DO_format} );
						}
							c3DataToMongo.setPurchaseOrderNumber(c3.getPurchaseOrderNumber());
							c3DataToMongo.setCurrent_WorkflowStateName_ID(c3.getCurrent_WorkflowStateName_ID());
							c3DataToMongo.setSite_ExternalReference(DO_format);
							
						//	System.out.println("from c3datatomongo "+c3DataToMongo);
							mongoTemplate.save(c3DataToMongo);
							
						}
					
					catch(Exception e) {System.out.println(e);}
					
				}
				}
			}
	}
		}		
			}
			
			
		}
		writer.writeAll(actual_data);
		writer.close();
        
	}
}
	