package com.example.demo;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="C3")
public class C3Master {
	
	@Id
    private String id;

	private String CustomField05;
    private String CustomField15;
    private String Site_ExternalReference;
    private String CustomStringTime01UTC;
    private String CustomStringTime02UTC;
    private String CustomStringTime04UTC;
	private String PurchaseOrderNumber;
	private String Current_WorkflowStateName_ID;
	
	public String getCurrent_WorkflowStateName_ID() {
		return Current_WorkflowStateName_ID;
	}

	public void setCurrent_WorkflowStateName_ID(String current_WorkflowStateName_ID) {
		Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
	}

	public C3Master() {}

	public C3Master(String id, String customField05, String customField15, String site_ExternalReference,
			String customStringTime01UTC, String customStringTime02UTC, String customStringTime04UTC,
			String purchaseOrderNumber, String current_WorkflowStateName_ID) {
		super();
		this.id = id;
		CustomField05 = customField05;
		CustomField15 = customField15;
		Site_ExternalReference = site_ExternalReference;
		CustomStringTime01UTC = customStringTime01UTC;
		CustomStringTime02UTC = customStringTime02UTC;
		CustomStringTime04UTC = customStringTime04UTC;
		PurchaseOrderNumber = purchaseOrderNumber;
		Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
	}

        public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPurchaseOrderNumber() {
		return PurchaseOrderNumber;
	}
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		PurchaseOrderNumber = purchaseOrderNumber;
	}
	public String getCustomField05() {
		return CustomField05;
	}
	public void setCustomField05(String customField05) {
		CustomField05 = customField05;
	}
	public String getCustomField15() {
		return CustomField15;
	}
	public void setCustomField15(String customField15) {
		CustomField15 = customField15;
	}
	public String getSite_ExternalReference() {
		return Site_ExternalReference;
	}
	public void setSite_ExternalReference(String site_ExternalReference) {
		Site_ExternalReference = site_ExternalReference;
	}
	public String getCustomStringTime01UTC() {
		return CustomStringTime01UTC;
	}
	public void setCustomStringTime01UTC(String customStringTime01UTC) {
		CustomStringTime01UTC = customStringTime01UTC;
	}
	public String getCustomStringTime02UTC() {
		return CustomStringTime02UTC;
	}
	public void setCustomStringTime02UTC(String customStringTime02UTC) {
		CustomStringTime02UTC = customStringTime02UTC;
	}
	public String getCustomStringTime04UTC() {
		return CustomStringTime04UTC;
	}
	public void setCustomStringTime04UTC(String customStringTime04UTC) {
		CustomStringTime04UTC = customStringTime04UTC;
	}
	
	

	
	
	
}
