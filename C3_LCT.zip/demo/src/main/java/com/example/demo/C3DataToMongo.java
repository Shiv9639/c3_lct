package com.example.demo;

import javax.annotation.Generated;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection ="C3CSVData")
public class C3DataToMongo {
	
	
	@Id
    private String id;
	private String PurchaseOrderNumber;
	private String Current_WorkflowStateName_ID;
    private String Site_ExternalReference;
    public C3DataToMongo() {
		// TODO Auto-generated constructor stub
	}
	public C3DataToMongo(String id,String purchaseOrderNumber, String current_WorkflowStateName_ID, String site_ExternalReference) {
		super();
		this.id = id;
		PurchaseOrderNumber = purchaseOrderNumber;
		Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
		Site_ExternalReference = site_ExternalReference;
		
	}
	
    
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPurchaseOrderNumber() {
		return PurchaseOrderNumber;
	}
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		PurchaseOrderNumber = purchaseOrderNumber;
	}
	public String getCurrent_WorkflowStateName_ID() {
		return Current_WorkflowStateName_ID;
	}
	public void setCurrent_WorkflowStateName_ID(String current_WorkflowStateName_ID) {
		Current_WorkflowStateName_ID = current_WorkflowStateName_ID;
	}
	public String getSite_ExternalReference() {
		return Site_ExternalReference;
	}
	public void setSite_ExternalReference(String site_ExternalReference) {
		Site_ExternalReference = site_ExternalReference;
	}
	
	

	

	
}
