package com.example.demo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface C3DataToMongRepo extends MongoRepository<C3DataToMongo, String> {

}
